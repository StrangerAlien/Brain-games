#!/usr/bin/env python3
from brain_games.cli import welcome_user
from brain_games.games.even import even_


def main():
    welcome_user()
    even_()


if __name__ == '__main__':
    main()
