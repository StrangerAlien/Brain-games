# from random import randint


def even_():
    print('working')
