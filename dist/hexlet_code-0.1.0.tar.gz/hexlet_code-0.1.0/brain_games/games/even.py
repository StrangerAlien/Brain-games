from random import randint
from brain_games.cli import welcome_user


def even_():
    welcome_user()
