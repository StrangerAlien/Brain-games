### Hexlet tests and linter status:
[![Actions Status](https://github.com/StrangerAlien/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/StrangerAlien/python-project-49/actions)
### Brain-even
[![asciicast](https://asciinema.org/a/jmpbUZX5PwqgindRdgM1tKRNl.svg)](https://asciinema.org/a/jmpbUZX5PwqgindRdgM1tKRNl)<br>
