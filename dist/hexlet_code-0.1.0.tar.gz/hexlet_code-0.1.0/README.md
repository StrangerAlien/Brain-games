### Hexlet tests and linter status:
[![Actions Status](https://github.com/StrangerAlien/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/StrangerAlien/python-project-49/actions)
### codeclimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/9a17010af79ad302ef4d/maintainability)](https://codeclimate.com/github/StrangerAlien/python-project-49/maintainability)